import React from 'react';
/* global google */
//TO DO : 
//READ THIS ENTIRE JS FILE AND MAKE PROPER DOCUMENTATION
//MOVE VARIABLES TO RIGHT PLACES
//INCLUDE A STATE FOR THIS WITH TERM AND CITY,COUNTRY
//DO TRY CATCH TO CATCH ERRORS WHEN WRONG ADDRESS OR NO CODE FOUND,they'll like this
//CHANGE IT SO CLICKS AND ENTER WORKS TO SUBMIT
//CHANGE IT SO WE CAN TYPE EVERYTHING AND HIT ENTER OR FIND ON DROPDOWN?
//
//Might need to move this somewhere else 

var country, city; 
  var componentForm = {
    //street_number: 'short_name',
    //route: 'long_name',
    locality: 'long_name',
    //administrative_area_level_1: 'short_name',
    country: 'short_name'

  };
//Props: onTermSubmit function (API Call) from App component is passed as a prop to this SearchBar component as onFormSubmit
class SearchBar extends React.Component {

	  constructor(props) {
    super(props);
    this.autocompleteInput = React.createRef();
    //Re-read our old imagecard to see how they did this ref before
    //Dont need -> this.autocomplete = null;
    //Dont need -> this.handlePlaceChanged = this.handlePlaceChanged.bind(this);

  }


  //Similar to initAutocomplete from Google API documentation. Initializes new autcomplete object, and adds callback function handlePlaceChanged as listener to autocomplete object
  componentDidMount() {
  	
    this.autocomplete = new google.maps.places.Autocomplete(this.autocompleteInput.current,
        {"types": ["(cities)"]});

    this.autocomplete.addListener('place_changed', this.handlePlaceChanged);
    
  }

  onFormSubmit = (event) => {
		event.preventDefault(); 
		this.props.onFormSubmit(`${city},${country}`);
	};

	//This is the callback function called when the dropdown is clicked 
  handlePlaceChanged = () => {
    const place = this.autocomplete.getPlace();
    console.log(place);
    // Get each component of the address from the place details
  // and fill the corresponding field on the form.
  //Loop through each item in the address_components response
  for (var i = 0; i < place.address_components.length; i++) {
    //Set addressType to the type from each item in the address_components response
    var addressType = place.address_components[i].types[0];
    if (componentForm[addressType]) 
    //If the addressType exists in the componentForm found above set val to that response element from the API (called with short_code or long_code depending on what is chosen above.
    //Essentially it iterates through each element in address_component array. It finds the type of each element and sets it to address type. If that address type is in the componentForm as well, it will set a new variable val to the value of that address type (value can be short_name or long_name depending on what is specified in the componentForm). Lastly it will find an input form with id set to the found addressType and set its value to the value determined from the API call.
    {
      var val = place.address_components[i][componentForm[addressType]];
      //If the addressType was determined to be country, we're gonna set the country variable defined above to the value returned. Same for locality (city)
      if (addressType==='country'){
        console.log('foundcountry');
        country = val; 
        console.log(country);
      }
 else if (addressType==='locality'){
        console.log('foundcity');
        city=val;
        console.log(city);
      }
      
    }
  }
  //Maybe update state for searchbar 'term' instead of value?
  //document.getElementById('autocomplete').value=`${city},${country}`;
  this.props.onFormSubmit(`${city},${country}`);
    
  }


	render(){
		return (
		<div className="search-bar ui segment">
		<form className="ui form" onSubmit={this.onFormSubmit}>
		<div className="field">
		<label>Enter Location</label>
  		<input ref={this.autocompleteInput}  id="autocomplete" placeholder="Enter your address"
         type="text"></input>
         </div>
		</form>


			</div>
			);
	}


}


export default SearchBar;