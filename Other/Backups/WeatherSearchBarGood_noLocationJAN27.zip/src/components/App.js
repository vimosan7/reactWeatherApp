import React from 'react'; 
import openweather from '../api/openweather';
import SearchBar from './SearchBar';
import WeatherDetail from './WeatherDetail';



class App extends React.Component { 

	//State of this App component is return of the onTermSubmit function (API Call). It has a property of weather which will be an array of the weather for the next 5 days in 3 hour intervals.
	state = {weather:null}; 

	//API CALL
	//This API call is passed to the SearchBar component as a prop. In the SearchBar component this API is called with a user entered 'term'. This 'term' is the city followed by country code, and is the parameter required for this API call. This API call is what sets the weather property in the state of this App component. 
	onTermSubmit =  async (term) => {

	const response = await openweather.get('/forecast', {
		params: { q: term }
		
	});
	this.setState({weather:response.data.list});
	console.log(this.state.weather);
	console.log(this.state.weather[0].weather[0].description);
	

	}




//onTermSubmit(API CALL) is passed as a prop to the SearchBar component as onFormSubmit
//Weather data returned from API call (which is also the state of this app) is passed as a prop to the WeatherData component 
render(){
	
	return (

		<div className="ui container">
		<SearchBar onFormSubmit={this.onTermSubmit}/>
		<WeatherDetail data={this.state.weather} />
		

		</div>
		);


		}



}


export default App; 